const CACHE='tf-modeler-v5-cache';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./manifest.json']))));
self.addEventListener('fetch',e=>{if(e.request.url.includes('cdn.jsdelivr.net'))return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))})
